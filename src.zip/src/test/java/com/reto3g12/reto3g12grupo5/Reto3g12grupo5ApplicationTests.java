package com.reto3g12.reto3g12grupo5;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Reto3g12grupo5ApplicationTests {

	@Test
	void contextLoads() {
	}

}
