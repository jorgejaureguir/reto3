package com.reto3g12.reto3g12grupo5;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;


@SpringBootApplication
public class Reto3g12grupo5Application {

	public static void main(String[] args) {
		SpringApplication.run(Reto3g12grupo5Application.class, args);
	}

}
